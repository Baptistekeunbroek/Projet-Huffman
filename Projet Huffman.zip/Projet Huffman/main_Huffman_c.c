#include <stdio.h>
#include <stdlib.h>


typedef struct liste_occur                                          //liste des occurence de chaque caract�res dans le texte
{
    char symbole;
    int nmb_occur;
    int code_bin[8];  //on stockera dans cette liste la traduction en binaire de chaque caract puis au moment de leur ajout
    struct liste_occur *suivant;
}liste_occur;

typedef struct liste_HUFFMAN
{
    int num_h;
    int poid;
    char symbole;
    struct liste_HUFFMAN *suivant;
    struct liste_HUFFMAN *droite;
    struct liste_HUFFMAN *gauche;
}liste_HUFFMAN;

liste_occur* creer_case_liste_occur(char c)
{
    int i=7;
    liste_occur* nouv_case;
    nouv_case = malloc(sizeof(liste_occur));
    nouv_case->symbole = c;
    nouv_case->nmb_occur = 0;
    for(i=0; c > 0; i++)                                                        //ici on converti le num ascii du caract�re c en binaire
      {                                                                              //par fraction on rempli les cases du tableu
        nouv_case->code_bin[i] = c%2;                                               //le num binaire est alors rentr� � l'envers dans le tableau
        c = c/2;                                                                            //c'est pourquoi dans la fonction affichage, la boucle for on affiche d'abord les derni�res cases du tableau
      }
    nouv_case->suivant = NULL;
    return(nouv_case);
}//fin creer_case_liste_occur

liste_occur* crea_liste_occur(FILE *livre, FILE *livre1_binaire, liste_occur *l_occur){
    char car_actuel;
    struct liste_occur *head;
    head=l_occur;
    while((car_actuel = fgetc(livre)) != EOF){
       // printf("%c",car_actuel);///optionel pour phase de teste
        do{
            if(l_occur->symbole == car_actuel){                                                             //on cherche si le car actuel est a la case point�
                                                                                                                //on ne fait rien et le while se finira de lui m�me puis incr�mentera le nmr d'occurence au bon endroit
            }else if(l_occur->suivant == NULL){                                                                         //SINON on pointe et recommence la verif a la case de la liste suivante si elle existe,
                l_occur->suivant = creer_case_liste_occur(car_actuel);                                                  //si elle n'existe pas on la cr�e en fonction du caract�re que lon cherche a placer actuelment
                l_occur = l_occur->suivant;
            }else{
                l_occur = l_occur->suivant;
            }//fin des if/else
        }while(l_occur->symbole != car_actuel);//fin du do-while
        l_occur->nmb_occur=l_occur->nmb_occur+1;                                                        //maintenant que la case l_occur o� on peut ranger le cacar en cour de lecture on on y augmente le nmbre d'occurence

        for(int i=7; i >= 0; i--){                                                                           //ici a chaque lecture de caract�re on le r�ecri dans le livre_binaire
            putc(l_occur->code_bin[i], livre1_binaire);                                                           //
        }
        l_occur=head;                                                                                           //on r�initialise toujours la t�te 'l_occur' de la liste qui ici sert de curseur de lectur

    }//fin du while

    return(l_occur);
}//fin crea_liste_occur

liste_HUFFMAN* creer_case_huff(liste_occur * l_occur){

    liste_HUFFMAN* nouv_case;
    nouv_case = malloc(sizeof(liste_occur));
    nouv_case->num_h = 0;
    nouv_case->symbole = l_occur->symbole;
    nouv_case->poid = l_occur->nmb_occur;
    nouv_case->droite = NULL;
    nouv_case->gauche = NULL;
    nouv_case->suivant = NULL;

    return(nouv_case);
}//fin creer_case_huff

liste_HUFFMAN* crea_liste_huff(liste_occur *l_occur,liste_HUFFMAN *l_huff){

    struct liste_HUFFMAN *head_h;
    struct liste_occur *head_o;
    head_o = l_occur;
    head_h = l_huff;
    l_occur = l_occur->suivant;
    //printf(" %c+%d",l_huff->symbole,l_huff->poid);///ligne de teste/debug
    while(l_occur != NULL){                                     //
        l_huff->suivant = creer_case_huff(l_occur);

        l_occur = l_occur->suivant;
        l_huff = l_huff->suivant;
        //printf(" %c+%d",l_huff->symbole,l_huff->poid);///ligne de teste/debug
    }//fin while

    l_occur = head_o;
    l_huff = head_h;

    return l_huff;
}//fin crea_liste_huff

liste_HUFFMAN* F_min_huff(liste_HUFFMAN *l_huff){
    struct liste_HUFFMAN *min_h;
    min_h = l_huff; //on initie toujours le minimum a la premi�re case de la liste
    struct liste_HUFFMAN *tampon;

    while(l_huff->suivant != NULL){                                                                                   //on parcour toute la liste des cases de huffman qui ne sont pas reli� a un neaud
        if((min_h->poid) > (l_huff->suivant->poid)){                                                        //si la case visit� a un poid plus faible que celle consid�r� comme tel, alors on la d�place au d�but de la liste
            tampon = l_huff->suivant->suivant;                                                              //une fois au d�but de la liste on est sur que l'osque l'on rendra la liste, la premi�re case celle de poid le plus faible
            l_huff->suivant->suivant = min_h;                                                               //cette case sera ensuite suprim� dans la fonction de trie
            min_h = l_huff->suivant;                                                                    //on r�p�tera l'op�ration deux fois pour isoler les deux cases de poid les plus faible pour les confier aux pointeurs droite et gauche
            l_huff->suivant = tampon;                                                                    //la nouvelle case de neaud ainsi cr�� prendra la place de premi�re case de la liste des cases n'�tant pas reli� a un neaud sup�rieur
        }else{                                                                                          //le programme se finissant lorsqu'il ne reste plus que une seul case qui deviendra alors la RACINE de l'arbre de HUFFMAN
            l_huff=l_huff->suivant;
        }//fin if
    }//fin while///////////////////////////////////////////////////////////
    printf("SORTI WHILE F_MIN");
    return min_h;
}//fin F_min_huff

liste_HUFFMAN* trier_liste_huff(liste_HUFFMAN *l_huff){         //VOIR LE COMMENTAIRE DANS LA FONCTION F_min_huff POUR UN SUPLEMENTT D'EXPLIATION sur le fonctionement de cette fonction
    struct liste_occur *l_occur_vide;
    l_occur_vide = creer_case_liste_occur('a');                            //fausse case de liste_occur qui sert de mod�le par la cr�ation des nouvelles case de la liste de neud de HUFFMAN
    struct liste_HUFFMAN *tampon;

    while(l_huff->suivant != NULL){                                  //si la t�te de liste_huffman ne pointe pas sur vide c'est qu'il reste encore au moins deux neaud dans la liste a fusionner pour donner la racine de l'arbre
        struct liste_HUFFMAN *neaud;                                         //on creer de nouvelle case neaud qui vont abriter dans leurs branches gauche et droite les deux plus petites case de la liste_uffman(l_huff)
        neaud = creer_case_huff(l_occur_vide);                              //les nouvelles cases creer sont vide cad sans caract�re et avec un poid = 0
        neaud->symbole = NULL;

        printf("\n\nchoix branche droite\n\n");
        l_huff = F_min_huff(l_huff);                                //ici on trouve la case au poid le plus faible et on en fait la branche droite du neaud en cour de creation
        printf("");afficher_liste_huff(l_huff);///liste de teste/debug
        tampon = l_huff->suivant;
        l_huff->suivant = NULL;
        neaud->droite = l_huff;
        l_huff = tampon;
        //printf("\n\n");afficher_liste_huff(l_huff);///liste de teste/debug

        printf("\n\nchoix branche gauche\n\n");

        l_huff = F_min_huff(l_huff);                                //ici on trouve la case au poid le plus faible et on en fait la branche gauche du neaud en cour de creation
        printf("");afficher_liste_huff(l_huff);///liste de teste/debug
        tampon = l_huff->suivant;
        l_huff->suivant = NULL;
        neaud->gauche = l_huff;
        l_huff = tampon;
        neaud->gauche->num_h = 1;                                           //le num des branche a gauche de HUFFMAN est =1 car a droite elle sont naturelement initi� a 0.

        neaud->poid = neaud->droite->poid + neaud->gauche->poid; //on aditionne le poid des deux sous branches deux sous branches pour determiner le poid du neaud
        tampon = l_huff;
        neaud->suivant = l_huff;
        l_huff=neaud;
        if(l_huff->symbole == NULL){printf("\n++++\n");afficher_liste_huff(l_huff);}///liste de teste/debug
    }//fin while
    return l_huff; //on rend la racine de l'arbre
}//fin trier_liste_huff

int F_trouver_la_voie(liste_HUFFMAN *l_huff,int chemin_valide ,char ccl,FILE *livre1_compr){

    if(ccl == l_huff->symbole ){
            chemin_valide = 1;
    }//verification si le symbole de la case ou  l'on pointe est la bonne

    if(chemin_valide == 1){
            putc(l_huff->num_h, livre1_compr);
            //printf("%d",l_huff->num_h);///pour afficher le code de huffman de chaque carac au cour de sa recherche
            return chemin_valide;//porte de sortie
    }else{

        if(l_huff->gauche != NULL){
        chemin_valide = F_trouver_la_voie(l_huff->gauche, chemin_valide ,ccl ,livre1_compr);}

        if(l_huff->droite != NULL){
        chemin_valide = F_trouver_la_voie(l_huff->droite, chemin_valide ,ccl ,livre1_compr);}

    }//fin du if de recherche et de recursivit�

}//fin F_trouver_la_voie

void F_lecture_reecriture_compr(FILE *livre1,FILE *livre1_compr,liste_HUFFMAN *l_huff){
    rewind(livre1); // retour du curseur de lecture au d�but du livre
    //fclose(livre1);
    //livre1 = fopen("Biblio/Livre1", "r");
    char ccl;//Caract en Cour de Lecture
    int chemin_valide ;

    while((ccl = fgetc(livre1)) != EOF){
        chemin_valide = 0;
        chemin_valide = F_trouver_la_voie(l_huff, chemin_valide ,ccl ,livre1_compr);     //ici retrasser le chemin jusqu'a la lettre en cour de lecture
        //if(chemin_valide==0){printf("FAIL");}
        printf("%c",ccl);
        // et putc des 0 ou des1 en fonction des embrenchements droite ou gauche pris
                                //UTILISER UNE FONCTION RECURSIVE ?
    }//fin du while

}//fin de void F_lecture_reecriture

void F_ecriture_dico(liste_occur *l_occur,liste_HUFFMAN *l_huff,FILE *livre1_compr_dico){
    int chemin_valide;
    while(l_occur != NULL){                                                           //on traverse toute la liste des occurences
        putc(l_occur->symbole, livre1_compr_dico);  putc(59, livre1_compr_dico);
        putc(l_occur->nmb_occur, livre1_compr_dico);   putc(59, livre1_compr_dico);
        chemin_valide = 0;
        chemin_valide = F_trouver_la_voie(l_huff, chemin_valide ,l_occur->symbole ,livre1_compr_dico);
        putc(32, livre1_compr_dico);
        l_occur = l_occur->suivant;
    }//fin while

    fclose(livre1_compr_dico);
}//fin F_ecriture_dico

void F_decodage(){


}//fin F_decodage

void F_contage_char_livres(){
    FILE *livre,*livre_compr,*livre_binaire;
    livre = fopen("Biblio/Livre1", "r");
    livre_compr = fopen("Biblio/Livre1_compr", "r");
    livre_binaire = fopen("Biblio/Livre1_binaire", "r");

    char ccl;                                                            //ici on lit 3 livre.txt
    int nbcaract=0;                                                     //afin d'afficher le nombre de caract�re pr�sent dans chaqun des douments
    while((ccl = fgetc(livre)) != EOF){                                //g�n�ralement on choisi le livre1 et les fichiers texte dans lesquelle il � �t� traduit en bianire et compr�ss�
        nbcaract++;
    }//fin du while
    printf("\n\nIl y a %d caracteres dans le livre1\n",nbcaract);

    nbcaract=0;
    while((ccl = fgetc(livre_compr)) != EOF){
        nbcaract++;
    }//fin du while
    printf("\nIl y a %d caracteres dans le livre1 compresse par Huffman\n",nbcaract);

    nbcaract=0;
    while((ccl = fgetc(livre_binaire)) != EOF){
        nbcaract++;
    }//fin du while
    printf("\nIl y a %d caracteres dans le livre1 en binaire\n",nbcaract);

    fclose(livre);
    fclose(livre_compr);
    fclose(livre_binaire);
}//fin de void F_contage_char_livres

void afficher_liste_occur(liste_occur *l_occur){
    int i=0;
    while(l_occur != NULL){
        printf("\n%c : %d : %d : ",l_occur->symbole ,l_occur->nmb_occur ,l_occur->symbole);
        for(i=7; i >= 0; i--){
            printf("%d",l_occur->code_bin[i]);
        }

        l_occur=l_occur->suivant;
    }//fin while
}//fin afficher_liste_occur

void afficher_liste_huff(liste_HUFFMAN *l_huff){
    while(l_huff != NULL){
        printf("  %c:%d ",l_huff->symbole ,l_huff->poid );

        l_huff=l_huff->suivant;
    }//fin while
}//fin afficher_liste_occur

int main()
{
    FILE *livre1,*livre1_compr,*livre1_binaire,*livre1_compr_dico;                                   //creation de pointeurs sur les fichiers texte livre
    livre1_compr_dico = fopen("Biblio/Livre1_compr_dico", "w+");
    livre1 = fopen("Biblio/Livre1", "r");                                        //on a rang� les fichiers texte dans un sous dossier "Biblio"
    livre1_compr = fopen("Biblio/Livre1_compr", "w+");                          //
    livre1_binaire = fopen("Biblio/Livre1_binaire", "w+");                     //

    struct liste_occur *l_occur;                                                   //cr�ation de la t�te de la liste de stockage des occurence et trad en bianire
    l_occur = creer_case_liste_occur(' ');                                        //initialistaions des variables de la premi�re case de la liste /// on consid�re ' ' comme par d�faut pr�sent dans la premi�re case
    l_occur = crea_liste_occur(livre1,livre1_binaire,l_occur);                   //lecture du livre 1, et stockage du nomre d'occurence de ses charact�res

    afficher_liste_occur(l_occur);                                             //affichage de la liste des occurences leur num ascii et leur conv en bianire

    printf("\n\nBARAGE 1 CREAION 1ere CASE DE l_huff\n");///ligne de teste et debug
    struct list_HUFFMAN *l_huff;                                                  //on suit la m�me m�thode de crea de liste que liste occur
    l_huff = creer_case_huff(l_occur);                                           //

    printf("\n\nBARAGE 2 CREATION LISTE DE TOUTES LES FEUILLES DE l_huff\n\n");///ligne de teste et debug
    l_huff = crea_liste_huff(l_occur,l_huff);
    afficher_liste_huff(l_huff);///liste de teste/debug                                //

    printf("\n\nBARAGE 3 CREATION des BRANCHES(neaud) et TRIE des feuilles\n\n");///ligne de teste et debug
    l_huff = trier_liste_huff(l_huff);                                         //une fois la liste de neaud cr�er on la trie pour former l'arbre de HUFFMAN
    printf("\nPORTE DE SORTIE arbre HUFMMAN fini\n");///ligne de teste et debug


    F_lecture_reecriture_compr(livre1,livre1_compr,l_huff);                     //on reecri le livre1 dans son fichier compress� par HUFFMAN
    F_ecriture_dico(l_occur,l_huff,livre1_compr_dico);

    fclose(livre1);                                                            //une fois les dossiers utilis� on les fermes
    fclose(livre1_compr);                                                     //
    fclose(livre1_binaire);                                                  //

    F_contage_char_livres();                    //affichage du nombre de caract�res dns les trois fichiers texte

    printf("\n LE PROGRAMME SE FINIT SANS BUG\n\n");
    return 0;
}














