
    struct liste_HUFFMAN *P_huff_precedent;
    while(l_huff->suivant !=NULL){
        if((min_h->poid) > (l_huff->poid)){
            tampon = l_huff->suivant;
            l_huff->suivant = min_h;
            P_huff_precedent->suivant = tampon;//**
            min_h = l_huff;

        }//fin if
        l_huff=l_huff->suivant;

    }//fin nouv while de secour



liste_HUFFMAN* F_min_huff(liste_HUFFMAN *l_huff){
    struct liste_HUFFMAN *min_h;
    min_h = l_huff; //on initie toujours le minimum a la premi�re case de la liste
    struct liste_HUFFMAN *tampon;

    while(l_huff->suivant->suivant != NULL){
        if((min_h->poid) > (l_huff->suivant->poid)){
            tampon = l_huff->suivant->suivant;
            l_huff->suivant->suivant = min_h;
            min_h = l_huff->suivant;
            l_huff->suivant = tampon;
        }//fin if
        l_huff=l_huff->suivant;
    }//fin while
    l_huff = min_h;
    printf("SORTI WHILE F_MIN");
    return l_huff;
}//fin F_min_huff

liste_HUFFMAN* trier_liste_huff(liste_HUFFMAN *l_huff){
    struct liste_occur *l_occur_vide;
    l_occur_vide = creer_case_liste_occur('a');                            //fausse case de liste_occur qui sert de mod�le par la cr�ation des nouvelles case de la liste de neud de HUFFMAN
    struct liste_HUFFMAN *tampon;
    struct liste_HUFFMAN *min_h;

    while(l_huff->suivant != NULL){                                  //si la t�te de liste_huffman ne pointe pas sur vide c'est qu'il reste encore au moins deux neaud dans la liste a fusionner pour donner la racine de l'arbre
        struct liste_HUFFMAN *neaud;                                         //on creer de nouvelle case neaud qui vont abriter dans leurs branches gauche et droite les deux plus petites case de la liste_uffman(l_huff)
        neaud = creer_case_huff(l_occur_vide);                              //les nouvelles cases creer sont vide cad sans caract�re et avec un poid = 0
        neaud->symbole = NULL;

        printf("\n\nchoix branche droite\n\n");


        //l_huff = F_min_huff(l_huff);                                //ici on trouve la case au poid le plus faible et on en fait la branche droite du neaud en cour de creation
        //fonction F_min
        min_h = l_huff;
        while(l_huff->suivant->suivant != NULL){
            if((min_h->poid) > (l_huff->suivant->poid)){
                tampon = l_huff->suivant->suivant;
                l_huff->suivant->suivant = min_h;
                min_h = l_huff->suivant;
                l_huff->suivant = tampon;
            }//fin if
            l_huff=l_huff->suivant;
        }//fin while
        l_huff = min_h;
        //fonction F_min
        printf("");afficher_liste_huff(l_huff);///liste de teste/debug
        tampon = l_huff->suivant;
        l_huff->suivant = NULL;
        neaud->droite = l_huff;
        l_huff = tampon;
        printf("\n\n");afficher_liste_huff(l_huff);///liste de teste/debug

        printf("\n\nchoix branche gauche\n\n");


        //l_huff = F_min_huff(l_huff);                                //ici on trouve la case au poid le plus faible et on en fait la branche gauche du neaud en cour de creation
        //fonction F_min
        min_h = l_huff;
        while(l_huff->suivant->suivant != NULL){
            if((min_h->poid) > (l_huff->suivant->poid)){
                tampon = l_huff->suivant->suivant;
                l_huff->suivant->suivant = min_h;
                min_h = l_huff->suivant;
                l_huff->suivant = tampon;
            }//fin if
            l_huff=l_huff->suivant;
        }//fin while
        l_huff = min_h;
        //fonction F_min


        printf("");afficher_liste_huff(l_huff);///liste de teste/debug
        neaud->num_h = 1;                                           //le num des branche a gauche de HUFFMAN est =1 car a droite elle sont naturelement initi� a 0.
        tampon = l_huff->suivant;
        l_huff->suivant = NULL;
        neaud->gauche = l_huff;
        l_huff = tampon;

        neaud->poid = neaud->droite->poid + neaud->gauche->poid; //on aditionne le poid des deux sous branches deux sous branches pour determiner le poid du neaud
        tampon = l_huff;
        neaud->suivant = l_huff;
        l_huff=neaud;
        if(l_huff->symbole == NULL){printf("\n++++\n");afficher_liste_huff(l_huff);}///liste de teste/debug
    }//fin while
    return l_huff; //on rend la racine de l'arbre
}//fin trier_liste_huff
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////
int *TABLEAU=NULL;
TABLEAU=(int*)malloc(taille*taille*sizeof(int));//allocation de l'espace
//////////////////////
/////////////
void printstringasbinary(char* s)
{
    // A small 9 characters buffer we use to perform the conversion
    char output[9];

    // Until the first character pointed by s is not a null character
    // that indicates end of string...
    while (*s)
    {
        // Convert the first character of the string to binary using itoa.
        // Characters in c are just 8 bit integers, at least, in noawdays computers.
        itoa(*s, output, 2);

        // print out our string and let's write a new line.
        puts(output);

        // we advance our string by one character,
        // If our original string was "ABC" now we are pointing at "BC".
        ++s;
    }
}
////////////////////////////////////////////






typedef struct arbre arbre;
struct arbre{
int val;
arbre *suivant;
arbre *avant;
};


void fonctionAffich(arbre *tete){
if (tete == NULL){
    return 0;
}else{
if (tete->gauche != NULL){
    printf("%d",tete->gauche->val);
    fonctionAffich(tete->gauche);
}
if (tete->droite != NULL){
    printf("%d",tete->droite->val);
    fonctionAffich(tete->droite);
}
}
}


    char tab_asci[255];//on stocke la valeur en int des caract de l'ascii
    for(i = 0; i < 255; i++) {
    tab_asci[i] = i;
    }

    /////////////////////////////////////////////////////2e part
    liste_HUFFMAN* F_min_huff(liste_HUFFMAN *head_h){
    struct liste_HUFFMAN *tampon;
    struct liste_HUFFMAN *true_head;
    struct liste_HUFFMAN *min_h;
    printf("  poid tete =%d  ",head_h->poid);///ligne de teste/debug
    min_h = head_h;                 //on initialise par default la plus petite case de la liste l_huff comme la premi�re
    head_h=head_h->suivant;          //on isole alors la case choisi comme min, son suivant ne pointant plus sur rien
    min_h->suivant=NULL;
    true_head = min_h;

/*
    if (head_h->poid < min_h->poid){
        min_h->suivant=head_h->suivant;
        tampon=head_h;
        head_h->suivant=NULL;
        head_h=min_h;
        min_h=tampon;
    }
*/

    while(head_h->suivant != NULL){
           // printf("\n   %c",head_h->symbole);///ligne teste/debug
        if((min_h->poid) > (head_h->suivant->poid)){

            min_h->suivant = head_h->suivant->suivant;
            head_h->suivant->suivant = NULL;
            tampon = head_h->suivant;
            head_h->suivant = min_h;
            min_h = tampon;
            printf("%d ",min_h->poid);///ligne de teste/debug

        }//finif
        head_h = head_h->suivant;
        //printf("  A2  ");//ligne de teste/debug
    }//fin while
    //head_h=true_head;
        printf("  poid min =%d  ",min_h->poid);///ligne de teste/debug
    return (min_h);//on rend donc un pointeur sur la case consid�r� la plus petite de la liste_huff puis retir� de cette m�me liste
}//fin F_min_huff




//this one work, i sware!


liste_HUFFMAN* F_min_huff(liste_HUFFMAN *l_huff){
    struct liste_HUFFMAN* head_h;
    struct liste_HUFFMAN *tampon;
    head_h = l_huff;
    struct liste_HUFFMAN *min_h;
    min_h = l_huff;
    while(l_huff->suivant != NULL){

        if((min_h->poid) > (head_h->suivant->poid)){

            tampon = min_h;


            min_h->suivant = head_h->suivant->suivant;
            head_h->suivant->suivant = NULL;
            tampon = head_h->suivant;
            head_h->suivant = min_h;
            min_h = tampon;
            printf("%d ",min_h->poid);///ligne de teste/debug

        }//finif

        l_huff=l_huff->suivant;
    }//fin while

    l_huff = head_h;
    return l_huff;
}//fin trier_HUFFMAN


////////////////////////////////////////////////////////// this time !!

liste_HUFFMAN* trie_liste_huff(liste_HUFFMAN *l_huff){
    struct liste_HUFFMAN *head_h;
    head_h = l_huff;
    struct liste_occur *l_occur_vide;
    l_occur_vide = creer_case_liste_occur('a');                            //fausse case de liste_occur qui sert de mod�le par la cr�ation des nouvelles case de la liste de neud de HUFFMAN

    while(l_huff->suivant != NULL){                                  //si la t�te de liste_huffman ne pointe pas sur vide c'est qu'il reste encore au moins deux neaud dans la liste a fusionner pour donner la racine de l'arbre
        struct liste_HUFFMAN *neaud;                                         //on creer de nouvelle case neaud qui vont abriter dans leurs branches gauche et droite les deux plus petites case de la liste_uffman(l_huff)
        neaud = creer_case_huff(l_occur_vide);                              //les nouvelles cases creer sont vide cad sans caract�re et avec un poid = 0
        //printf("!! %c !!",neaud->symbole);///ligne de teste/debug
        neaud->symbole = NULL;
        //printf("!! %c !!",neaud->symbole);///ligne de teste/debug

        l_huff = F_min_huff(l_huff);                                //ici on trouve la case au poid le plus vide et on en fait la branche du neaud en cour de creation
        head_h = l_huff->suivant;
        l_huff->suivant = NULL;
        neaud->droite = l_huff;
        l_huff=head_h;
        printf("%c -",neaud->droite->symbole);///ligne de teste/debug
        printf("%d ",l_huff->poid);///ligne de teste/debug

        neaud->gauche = F_min_huff(l_huff);
        head_h = l_huff->suivant;
        l_huff->suivant= NULL;
        neaud->gauche = l_huff;
        l_huff=head_h;                              //on r�p�te pour la branche droite et gauche
        printf("\n  M3  ");///ligne de teste/debug

        neaud->poid = (neaud->droite->poid) + (neaud->gauche->poid);   //les deux branche cr�er on aditionne leurs poid pour determiner celui du nouveau neud
        printf("  poid neaud =%d - %c - %c ",neaud->poid,neaud->droite->symbole,neaud->gauche->symbole);///ligne de teste/debug
        neaud->suivant = l_huff;                                  //enfin pour ins�rer le neud dans la fonction on lui fait prendre le role de la t�te de la liste il est tempor�rement la racine de l'arbre
        l_huff = neaud;                                            // le neaud pointe donc sur l'ancienne l'ancienne case point� par la t�te et la t�te pointe maintenant sur le neaud


    }//fin while
    printf("  S5  ");//ligne de teste/debug
    //l_huff = head_h; //vestige?
    //l_huff = head_h;
    return l_huff; //on rend la racine de l'arbre
}//fin trier_liste_huff


////////////
if(l_huff->suivant != NULL){
            if((min_h->poid) > (l_huff->poid)){
            tampon = l_huff->suivant;
            l_huff->suivant = min_h;
            min_h = l_huff->suivant;
            l_huff->suivant = tampon;

        }//fin if
    }//fin if de secour


    ///////////


liste_HUFFMAN* F_min_hufff(liste_HUFFMAN *l_huff){
    struct liste_HUFFMAN* head_h;
    struct liste_HUFFMAN *tampon;
    head_h = l_huff;
    struct liste_HUFFMAN *min_h;
    min_h = l_huff; //min doit toujours pointer la premi�re case de la liste car on y d�place la case la plus petite de la liste pour qu'elle soit ensuite d�coup� a la sortie de la fonction
    while(l_huff->suivant != NULL){

        if((min_h->poid) > (l_huff->suivant->poid)){

            tampon = l_huff->suivant;
            l_huff->suivant = l_huff->suivant->suivant;
            tampon->suivant = min_h;
            min_h = tampon;
            /*
            min_h->suivant = head_h->suivant->suivant;
            head_h->suivant->suivant = NULL;
            tampon = head_h->suivant;
            head_h->suivant = min_h;
            min_h = tampon;
            */
        }//finif

        l_huff=l_huff->suivant;
    }//fin while

    l_huff = min_h;
    return l_huff;
}//fin trier_HUFFMAN
